//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
//                                                                      //
// If you are using Chrome, open the Developer Tools and click the gear //
// icon in its lower right corner. In the General Settings panel, turn  //
// on 'Enable source maps'.                                             //
//                                                                      //
// If you are using Firefox 23, go to `about:config` and set the        //
// `devtools.debugger.source-maps-enabled` preference to true.          //
// (The preference should be on by default in Firefox 24; versions      //
// older than 23 do not support source maps.)                           //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var Template = Package.templating.Template;
var ReactiveDict = Package['reactive-dict'].ReactiveDict;
var _ = Package.underscore._;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var FlowLayout;

(function () {

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// packages/meteorhacks:flow-layout/lib/client/namespace.js                 //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
                                                                            //
FlowLayout = {};                                                            // 1
//////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// packages/meteorhacks:flow-layout/lib/client/layout.js                    //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
                                                                            //
var currentLayoutName = null;                                               // 1
var currentLayout = null;                                                   // 2
var currentRegions = new ReactiveDict();                                    // 3
var currentData;                                                            // 4
var _isReady = false;                                                       // 5
                                                                            // 6
FlowLayout.setRoot = function(root) {                                       // 7
  FlowLayout._root = root;                                                  // 8
};                                                                          // 9
                                                                            // 10
FlowLayout.render = function render(layout, regions) {                      // 11
  Meteor.startup(function() {                                               // 12
    // To make sure dom is loaded before we do rendering layout.            // 13
    // Related to issue #25                                                 // 14
    if(!_isReady) {                                                         // 15
      Meteor.defer(function() {                                             // 16
        _isReady = true;                                                    // 17
        FlowLayout._render(layout, regions)                                 // 18
      });                                                                   // 19
    } else {                                                                // 20
      FlowLayout._render(layout, regions);                                  // 21
    }                                                                       // 22
  });                                                                       // 23
};                                                                          // 24
                                                                            // 25
FlowLayout.reset = function reset() {                                       // 26
  var layout = currentLayout;                                               // 27
  if(layout) {                                                              // 28
    if(layout._domrange) {                                                  // 29
      // if it's rendered let's remove it right away                        // 30
      Blaze.remove(layout);                                                 // 31
    } else {                                                                // 32
      // if not let's remove it when it rendered                            // 33
      layout.onViewReady(function() {                                       // 34
        Blaze.remove(layout);                                               // 35
      });                                                                   // 36
    }                                                                       // 37
                                                                            // 38
    currentLayout = null;                                                   // 39
    currentLayoutName = null;                                               // 40
    currentRegions = new ReactiveDict();                                    // 41
  }                                                                         // 42
};                                                                          // 43
                                                                            // 44
FlowLayout._regionsToData = function _regionsToData(regions, data) {        // 45
  data = data || {};                                                        // 46
  _.each(regions, function(value, key) {                                    // 47
    currentRegions.set(key, value);                                         // 48
    data[key] = FlowLayout._buildRegionGetter(key);                         // 49
  });                                                                       // 50
                                                                            // 51
  return data;                                                              // 52
};                                                                          // 53
                                                                            // 54
FlowLayout._updateRegions = function _updateRegions(regions) {              // 55
  var needsRerender = false;                                                // 56
  // unset removed regions from the exiting data                            // 57
  _.each(currentData, function(value, key) {                                // 58
    if(regions[key] === undefined) {                                        // 59
      currentRegions.set(key, undefined);                                   // 60
      delete currentData[key];                                              // 61
    }                                                                       // 62
  });                                                                       // 63
                                                                            // 64
  _.each(regions, function(value, key) {                                    // 65
    // if this key does not yet exist then blaze                            // 66
    // has no idea about this key and it won't get the value of this key    // 67
    // so, we need to force a re-render                                     // 68
    if(currentData && currentData[key] === undefined) {                     // 69
      needsRerender = true;                                                 // 70
      // and, add the data function for this new key                        // 71
      currentData[key] = FlowLayout._buildRegionGetter(key);                // 72
    }                                                                       // 73
    currentRegions.set(key, value);                                         // 74
  });                                                                       // 75
                                                                            // 76
  // force re-render if we need to                                          // 77
  if(currentLayout && needsRerender) {                                      // 78
    currentLayout.dataVar.dep.changed();                                    // 79
  }                                                                         // 80
};                                                                          // 81
                                                                            // 82
FlowLayout._getRootDomNode = function _getRootDomNode() {                   // 83
  var root = FlowLayout._root                                               // 84
  if(!root) {                                                               // 85
    root = $('<div id="__flow-root"></div>');                               // 86
    $('body').append(root);                                                 // 87
    FlowLayout.setRoot(root);                                               // 88
  }                                                                         // 89
                                                                            // 90
  // We need to use $(root) here because when calling FlowLayout.setRoot(), // 91
  // there won't have any available DOM elements                            // 92
  // So, we need to defer that.                                             // 93
  var domNode = $(root).get(0);                                             // 94
  if(!domNode) {                                                            // 95
    throw new Error("Root element does not exist");                         // 96
  }                                                                         // 97
                                                                            // 98
  return domNode;                                                           // 99
};                                                                          // 100
                                                                            // 101
FlowLayout._buildRegionGetter = function _buildRegionGetter(key) {          // 102
  return function() {                                                       // 103
    return currentRegions.get(key);                                         // 104
  };                                                                        // 105
};                                                                          // 106
                                                                            // 107
FlowLayout._render = function _render(layout, regions) {                    // 108
  var rootDomNode = FlowLayout._getRootDomNode();                           // 109
  if(currentLayoutName != layout) {                                         // 110
    // remove old view                                                      // 111
    FlowLayout.reset();                                                     // 112
    currentData = FlowLayout._regionsToData(regions);                       // 113
                                                                            // 114
    currentLayout = Blaze._TemplateWith(currentData, function() {           // 115
      return Spacebars.include(Template[layout]);                           // 116
    });                                                                     // 117
                                                                            // 118
    Blaze.render(currentLayout, rootDomNode);                               // 119
    currentLayoutName = layout;                                             // 120
  } else {                                                                  // 121
    FlowLayout._updateRegions(regions);                                     // 122
  }                                                                         // 123
};                                                                          // 124
//////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['meteorhacks:flow-layout'] = {
  FlowLayout: FlowLayout
};

})();
