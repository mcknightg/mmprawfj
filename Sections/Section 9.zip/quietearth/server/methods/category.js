
Meteor.methods({
    addCategory:function(category){
        var exists = Category.findOne({name:category.name});
        if(!exists){
            return Category.insert(category);
        }

    }
});