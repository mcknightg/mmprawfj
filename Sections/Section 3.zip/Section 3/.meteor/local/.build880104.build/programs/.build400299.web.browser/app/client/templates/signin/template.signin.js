(function(){
Template.__checkName("signin");
Template["signin"] = new Template("Template.signin", (function() {
  var view = this;
  return HTML.Raw('<div class="row">\n      <div class="col-md-6 col-md-offset-3">\n          <form class="signin-form">\n              <div class="panel panel-info">\n                  <div class="panel-heading">\n                      <h3 class="plain huge">Sign In </h3>\n                      <small>Not Registered ? <a href="/register">Register</a></small>\n                  </div>\n                  <div class="panel-body">\n                      <div class="form-group col-lg-12">\n                          <label class="plain">Email</label>\n                          <input type="text" class="form-control plain" id="email">\n                      </div>\n                      <div class="form-group col-lg-12">\n                          <label class="plain">Password</label>\n                          <input type="password" class="form-control plain" id="password">\n                      </div>\n                  </div>\n                  <div class="panel-footer">\n                      <button type="submit" class="btn btn-info plain">Sign In</button>\n                  </div>\n              </div>\n          </form>\n      </div>\n  </div>');
}));

})();
