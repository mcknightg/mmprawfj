Template.home.onCreated(function(){
    this.subscribe('products');
});