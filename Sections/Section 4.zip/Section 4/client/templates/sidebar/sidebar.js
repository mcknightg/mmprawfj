Template.sidebar.helpers({
    'categories':function(){
        return Category.find();
    }
});