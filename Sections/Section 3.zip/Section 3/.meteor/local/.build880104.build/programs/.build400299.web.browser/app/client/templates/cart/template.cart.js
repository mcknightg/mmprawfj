(function(){
Template.__checkName("cart");
Template["cart"] = new Template("Template.cart", (function() {
  var view = this;
  return "Cart";
}));

})();
