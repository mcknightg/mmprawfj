(function(){
Template.__checkName("sidebar");
Template["sidebar"] = new Template("Template.sidebar", (function() {
  var view = this;
  return HTML.Raw('<div class="row">\n        <div class="col-md-12 hidden-sm hidden-xs">\n            <ul class="list-unstyled side-nav" id="tree1">\n                    <li><a href="/category/example">Example Category</a></li>\n                    <li><a href="/category/other">Other Category</a></li>\n                    <li><a href="/category/anotherexample">Another Category</a></li>\n            </ul>\n        </div>\n\n    </div>');
}));

})();
