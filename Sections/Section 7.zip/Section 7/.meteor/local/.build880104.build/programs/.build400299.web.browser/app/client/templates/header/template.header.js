(function(){
Template.__checkName("header");
Template["header"] = new Template("Template.header", (function() {
  var view = this;
  return HTML.NAV({
    role: "navigation",
    "class": "navbar navbar-default navbar-fixed-top"
  }, "\n        ", HTML.DIV({
    "class": "container-fluid"
  }, "\n            ", HTML.Raw('<div class="navbar-header">\n                <a href="/admin" class="navbar-brand bigger">Quiet Earth</a>\n\n            </div>'), "\n\n            ", HTML.DIV({
    "class": "collapse navbar-collapse",
    id: "main-nav"
  }, "\n                ", HTML.Raw('<ul class="nav navbar-nav">\n                    <li class="active">\n                        <a href="/">Home</a>\n                    </li>\n                    <li><a href="/admin">Admin</a></li>\n                    <li><a href="/profile">My Profile</a></li>\n                    <li><a href="/cart"> <i class="fa fa-shopping-cart"></i> Cart</a></li>\n                </ul>'), "\n                ", HTML.DIV({
    "class": "navbar-right plain"
  }, "\n                    ", Blaze.If(function() {
    return Spacebars.call(view.lookup("currentUser"));
  }, function() {
    return [ "\n\n                        ", HTML.A({
      style: "margin-left:20px;",
      href: "/signout",
      "class": "btn btn-danger navbar-btn"
    }, "\n                            ", HTML.IMG({
      width: "20px",
      src: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "profile", "avatar"));
      },
      alt: "Avatar",
      "class": "img-circle"
    }), "\n                            Sign Out  ", Blaze.View("lookup:currentUser.profile.firstname", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "profile", "firstname"));
    }), " ", Blaze.View("lookup:currentUser.profile.lastname", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "profile", "lastname"));
    })), "\n\n                    " ];
  }, function() {
    return [ "\n                        ", HTML.A({
      href: "/signin",
      "class": "btn btn-default navbar-btn"
    }, "Sign In"), "\n                        ", HTML.A({
      href: "/register",
      "class": "btn btn-primary navbar-btn"
    }, "Register"), "\n                    " ];
  }), "\n                "), "\n\n            "), "\n        "), "\n    ");
}));

})();
