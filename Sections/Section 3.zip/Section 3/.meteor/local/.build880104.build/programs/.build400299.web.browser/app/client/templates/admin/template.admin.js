(function(){
Template.__checkName("admin");
Template["admin"] = new Template("Template.admin", (function() {
  var view = this;
  return [ HTML.DIV({
    "class": "col-sm-6"
  }, "\n      ", HTML.Raw('<h2 class="heading">Product Administration</h2>'), "\n      ", HTML.Raw('<div class="form-group">\n          <label class="control-label">Product Name</label>\n          <input id="productname" type="text" class="form-control input-sm">\n      </div>'), "\n      ", HTML.Raw('<div class="form-group">\n          <label class="control-label">Category</label>\n          <input id="category" type="text" class="form-control input-sm">\n      </div>'), "\n      ", HTML.DIV({
    "class": "form-group"
  }, "\n          ", HTML.Raw('<label class="control-label">Description</label>'), "\n          ", HTML.TEXTAREA({
    id: "description",
    "class": "form-control"
  }), "\n      "), "\n      ", HTML.Raw('<div class="form-group">\n          <label class="control-label">Price</label>\n          <input id="price" type="text" class="form-control input-sm">\n      </div>'), "\n      ", HTML.Raw('<div class="form-group">\n          <label class="control-label">Rating</label>\n          <input id="rating" type="text" class="form-control input-sm">\n      </div>'), "\n      ", HTML.Raw('<div class="row">\n          <div class="col-sm-4"></div>\n          <div class="col-sm-4">\n              <div class="control-group">\n                  <label class="control-label"></label>\n                  <div class="controls">\n                      <button class="btn btn-info btn-md">\n                          <i class="fa fa-database"></i>\n                          Add Product\n                      </button>\n                  </div>\n              </div>\n          </div>\n          <div class="col-sm-4"></div>\n      </div>'), "\n\n  "), "\n    ", HTML.DIV({
    "class": "col-md-6"
  }, "\n        ", HTML.TABLE({
    "class": "table table-striped table-bordered table-responsive table-hover"
  }, "\n            ", HTML.THEAD("\n            ", HTML.TR({
    "class": "success"
  }, "\n                ", HTML.TH("Product Name"), "\n                ", HTML.TH("Price"), "\n                ", HTML.TH("Category"), "\n                ", HTML.TH("Remove"), "\n            "), "\n            "), "\n            ", HTML.TBODY("\n            ", HTML.TR("\n                ", HTML.TD("Apple Crisp"), "\n                ", HTML.TD("$12.99"), "\n                ", HTML.TD("Fruity"), "\n                ", HTML.TD(HTML.I({
    "class": "fa fa-trash alert-danger"
  })), "\n            "), "\n            "), "\n        "), "\n    ") ];
}));

})();
