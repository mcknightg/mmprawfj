module.exports = function(config) {
  config.set({
  "port": 9876,
  "basePath": "/Users/georgemcknight/Desktop/Mastering Meteor JS/Movies/09_Testing-Your-Application/9.2-Writing_useful_tests/quietearth",
  "frameworks": [
    "jasmine"
  ],
  "browsers": [
    "Chrome"
  ],
  "plugins": [
    "karma-jasmine",
    "karma-chrome-launcher",
    "karma-coffee-preprocessor"
  ],
  "files": [
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/client/unit/assets/__meteor_runtime_config__.js",
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/underscore.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/meteor.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/json.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/base64.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/ejson.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/logging.js",
      "nocache": true
    },
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/client/unit/assets/mocks/packages/reload.js",
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/tracker.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/random.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/retry.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/check.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/id-map.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/ordered-dict.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/geojson-utils.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/minimongo.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/ddp.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/mongo.js",
      "nocache": true
    },
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/client/unit/assets/mocks/packages/autoupdate.js",
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/meteor-platform.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/jquery.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/deps.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/htmljs.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/observe-sequence.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/reactive-var.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/blaze.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/templating.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/reactive-dict.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/meteorhacks_flow-layout.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cosmos_browserify.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/meteorhacks_flow-router.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/twbs_bootstrap.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/npm-bcrypt.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/localstorage.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/callback-hook.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/accounts-base.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/sha.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/srp.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/accounts-password.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/alanning_roles.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/fortawesome_fontawesome.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_standard-packages.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_base-package.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/livedata.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/mongo-livedata.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/raix_eventemitter.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_storage-adapter.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_gridfs.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/matb33_collection-hooks.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/dburles_collection-helpers.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/aldeed_simple-schema.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/aldeed_collection2.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/url.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/http.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/webapp.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/velocity_meteor-internals.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/velocity_source-map-support.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/velocity_shim.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/simple_json-routes.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/sanjo_long-running-child-process.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/amplify.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/less.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/xolvio_cucumber.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/velocity_console-reporter.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/coffeescript.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/practicalmeteor_chai.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/practicalmeteor_loglevel.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/velocity_meteor-stubs.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/session.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/ui.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/spacebars.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/launch-screen.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_data-man.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_file.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_tempstore.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_http-methods.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_http-publish.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_access-point.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_reactive-property.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_reactive-list.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_power-queue.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_upload-http.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_collection.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_collection-filters.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_worker.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/global-imports.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/service-configuration.js",
      "nocache": true
    },
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/client/unit/assets/jasmine-jquery.js",
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/.npm/package/node_modules/component-mocker/index.js",
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/lib/mock.js",
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/lib/VelocityTestReporter.js",
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/client/unit/assets/adapter.js",
    ".meteor/local/build/programs/server/assets/packages/velocity_meteor-stubs/index.js",
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/client/unit/assets/helpers/iron_router.js",
    "tests/jasmine/client/unit/**/*-+(stub|stubs|mock|mocks).+(js|coffee|litcoffee|coffee.md)",
    {
      "pattern": ".meteor/local/build/programs/web.browser/6f2b7db695256f754439117d1db2572db94c3d3d.css",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/admin/template.admin.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/admin/template.unauthorized.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/cart/template.cart.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/category/template.category.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/checkout/template.checkout.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/header/template.header.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/home/template.home.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/layout/template.layout.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/product/template.product.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/profile/template.profile.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/register/template.register.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/reusables/template.panel.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/sidebar/template.sidebar.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/signin/template.signin.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/template.quietearth.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/admin/admin.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/cart/cart.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/category/category.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/checkout/checkout.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/header/header.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/home/home.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/product/product.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/profile/profile.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/register/register.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/reusables/panel.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/sidebar/sidebar.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/signin/signin.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/both/collections/cart.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/both/collections/category.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/both/collections/fileuploads.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/both/collections/product.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/both/router/routes.js",
      "nocache": true
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/helpers/stringHelpers.js",
      "nocache": true
    },
    "tests/jasmine/client/unit/**/*.+(js|coffee|litcoffee|coffee.md)"
  ],
  "client": {
    "args": [
      {
        "autoupdateVersion": "unknown",
        "autoupdateVersionRefreshable": "unknown",
        "autoupdateVersionCordova": "none",
        "meteorRelease": "METEOR@1.1.0.3",
        "ROOT_URL": "http://localhost:3000/",
        "ROOT_URL_PATH_PREFIX": "",
        "appId": "1tdp9wq6dso4c7vn8io"
      }
    ]
  },
  "browserDisconnectTimeout": 10000,
  "browserNoActivityTimeout": 15000,
  "preprocessors": {
    "**/*.{coffee,litcoffee,coffee.md}": [
      "coffee"
    ]
  },
  "coffeePreprocessor": {
    "options": {
      "bare": true,
      "sourceMap": true
    }
  }
});
};