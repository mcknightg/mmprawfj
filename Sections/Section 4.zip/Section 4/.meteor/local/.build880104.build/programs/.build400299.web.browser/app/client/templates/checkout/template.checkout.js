(function(){
Template.__checkName("checkout");
Template["checkout"] = new Template("Template.checkout", (function() {
  var view = this;
  return "Checkout";
}));

})();
