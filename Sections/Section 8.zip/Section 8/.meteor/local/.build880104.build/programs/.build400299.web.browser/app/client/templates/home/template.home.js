(function(){
Template.__checkName("home");
Template["home"] = new Template("Template.home", (function() {
  var view = this;
  return HTML.Raw('<div class="row">\n       <div class="jumbotron">\n           <h1>Welcome to Quiet Earth</h1>\n           <p>Soy wax candles, made from the best stuff on the planet.</p>\n       </div>\n   </div>');
}));

})();
