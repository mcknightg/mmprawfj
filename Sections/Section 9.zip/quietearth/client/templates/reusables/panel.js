Template.panel.events({
    'click .closePanel':function(){
        Session.set('isCheckingOut',false);
    }
});