//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
//                                                                      //
// If you are using Chrome, open the Developer Tools and click the gear //
// icon in its lower right corner. In the General Settings panel, turn  //
// on 'Enable source maps'.                                             //
//                                                                      //
// If you are using Firefox 23, go to `about:config` and set the        //
// `devtools.debugger.source-maps-enabled` preference to true.          //
// (The preference should be on by default in Firefox 24; versions      //
// older than 23 do not support source maps.)                           //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ReactiveDict = Package['reactive-dict'].ReactiveDict;
var ReactiveVar = Package['reactive-var'].ReactiveVar;

/* Package-scope variables */
var FlowRouter, page, qs, Triggers, Router, Group, Route;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:flow-router/client.browserify.js                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
// shim for using process in browser

var process = module.exports = {};
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = setTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            currentQueue[queueIndex].run();
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    clearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        setTimeout(drainQueue, 0);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

// TODO(shtylman)
process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };

},{}],2:[function(require,module,exports){
page = require('page');
qs   = require('qs');

},{"page":3,"qs":6}],3:[function(require,module,exports){
(function (process){
  /* globals require, module */

  'use strict';

  /**
   * Module dependencies.
   */

  var pathtoRegexp = require('path-to-regexp');

  /**
   * Module exports.
   */

  module.exports = page;

  /**
   * Detect click event
   */
  var clickEvent = ('undefined' !== typeof document) && document.ontouchstart ? 'touchstart' : 'click';

  /**
   * To work properly with the URL
   * history.location generated polyfill in https://github.com/devote/HTML5-History-API
   */

  var location = ('undefined' !== typeof window) && (window.history.location || window.location);

  /**
   * Perform initial dispatch.
   */

  var dispatch = true;


  /**
   * Decode URL components (query string, pathname, hash).
   * Accommodates both regular percent encoding and x-www-form-urlencoded format.
   */
  var decodeURLComponents = true;

  /**
   * Base path.
   */

  var base = '';

  /**
   * Running flag.
   */

  var running;

  /**
   * HashBang option
   */

  var hashbang = false;

  /**
   * Previous context, for capturing
   * page exit events.
   */

  var prevContext;

  /**
   * Register `path` with callback `fn()`,
   * or route `path`, or redirection,
   * or `page.start()`.
   *
   *   page(fn);
   *   page('*', fn);
   *   page('/user/:id', load, user);
   *   page('/user/' + user.id, { some: 'thing' });
   *   page('/user/' + user.id);
   *   page('/from', '/to')
   *   page();
   *
   * @param {String|Function} path
   * @param {Function} fn...
   * @api public
   */

  function page(path, fn) {
    // <callback>
    if ('function' === typeof path) {
      return page('*', path);
    }

    // route <path> to <callback ...>
    if ('function' === typeof fn) {
      var route = new Route(path);
      for (var i = 1; i < arguments.length; ++i) {
        page.callbacks.push(route.middleware(arguments[i]));
      }
      // show <path> with [state]
    } else if ('string' === typeof path) {
      page['string' === typeof fn ? 'redirect' : 'show'](path, fn);
      // start [options]
    } else {
      page.start(path);
    }
  }

  /**
   * Callback functions.
   */

  page.callbacks = [];
  page.exits = [];

  /**
   * Current path being processed
   * @type {String}
   */
  page.current = '';

  /**
   * Number of pages navigated to.
   * @type {number}
   *
   *     page.len == 0;
   *     page('/login');
   *     page.len == 1;
   */

  page.len = 0;

  /**
   * Get or set basepath to `path`.
   *
   * @param {String} path
   * @api public
   */

  page.base = function(path) {
    if (0 === arguments.length) return base;
    base = path;
  };

  /**
   * Bind with the given `options`.
   *
   * Options:
   *
   *    - `click` bind to click events [true]
   *    - `popstate` bind to popstate [true]
   *    - `dispatch` perform initial dispatch [true]
   *
   * @param {Object} options
   * @api public
   */

  page.start = function(options) {
    options = options || {};
    if (running) return;
    running = true;
    if (false === options.dispatch) dispatch = false;
    if (false === options.decodeURLComponents) decodeURLComponents = false;
    if (false !== options.popstate) window.addEventListener('popstate', onpopstate, false);
    if (false !== options.click) {
      document.addEventListener(clickEvent, onclick, false);
    }
    if (true === options.hashbang) hashbang = true;
    if (!dispatch) return;
    var url = (hashbang && ~location.hash.indexOf('#!')) ? location.hash.substr(2) + location.search : location.pathname + location.search + location.hash;
    page.replace(url, null, true, dispatch);
  };

  /**
   * Unbind click and popstate event handlers.
   *
   * @api public
   */

  page.stop = function() {
    if (!running) return;
    page.current = '';
    page.len = 0;
    running = false;
    document.removeEventListener(clickEvent, onclick, false);
    window.removeEventListener('popstate', onpopstate, false);
  };

  /**
   * Show `path` with optional `state` object.
   *
   * @param {String} path
   * @param {Object} state
   * @param {Boolean} dispatch
   * @return {Context}
   * @api public
   */

  page.show = function(path, state, dispatch, push) {
    var ctx = new Context(path, state);
    page.current = ctx.path;
    if (false !== dispatch) page.dispatch(ctx);
    if (false !== ctx.handled && false !== push) ctx.pushState();
    return ctx;
  };

  /**
   * Goes back in the history
   * Back should always let the current route push state and then go back.
   *
   * @param {String} path - fallback path to go back if no more history exists, if undefined defaults to page.base
   * @param {Object} [state]
   * @api public
   */

  page.back = function(path, state) {
    if (page.len > 0) {
      // this may need more testing to see if all browsers
      // wait for the next tick to go back in history
      history.back();
      page.len--;
    } else if (path) {
      setTimeout(function() {
        page.show(path, state);
      });
    }else{
      setTimeout(function() {
        page.show(base, state);
      });
    }
  };


  /**
   * Register route to redirect from one path to other
   * or just redirect to another route
   *
   * @param {String} from - if param 'to' is undefined redirects to 'from'
   * @param {String} [to]
   * @api public
   */
  page.redirect = function(from, to) {
    // Define route from a path to another
    if ('string' === typeof from && 'string' === typeof to) {
      page(from, function(e) {
        setTimeout(function() {
          page.replace(to);
        }, 0);
      });
    }

    // Wait for the push state and replace it with another
    if ('string' === typeof from && 'undefined' === typeof to) {
      setTimeout(function() {
        page.replace(from);
      }, 0);
    }
  };

  /**
   * Replace `path` with optional `state` object.
   *
   * @param {String} path
   * @param {Object} state
   * @return {Context}
   * @api public
   */


  page.replace = function(path, state, init, dispatch) {
    var ctx = new Context(path, state);
    page.current = ctx.path;
    ctx.init = init;
    ctx.save(); // save before dispatching, which may redirect
    if (false !== dispatch) page.dispatch(ctx);
    return ctx;
  };

  /**
   * Dispatch the given `ctx`.
   *
   * @param {Object} ctx
   * @api private
   */

  page.dispatch = function(ctx) {
    var prev = prevContext,
      i = 0,
      j = 0;

    prevContext = ctx;

    function nextExit() {
      var fn = page.exits[j++];
      if (!fn) return nextEnter();
      fn(prev, nextExit);
    }

    function nextEnter() {
      var fn = page.callbacks[i++];

      if (ctx.path !== page.current) {
        ctx.handled = false;
        return;
      }
      if (!fn) return unhandled(ctx);
      fn(ctx, nextEnter);
    }

    if (prev) {
      nextExit();
    } else {
      nextEnter();
    }
  };

  /**
   * Unhandled `ctx`. When it's not the initial
   * popstate then redirect. If you wish to handle
   * 404s on your own use `page('*', callback)`.
   *
   * @param {Context} ctx
   * @api private
   */

  function unhandled(ctx) {
    if (ctx.handled) return;
    var current;

    if (hashbang) {
      current = base + location.hash.replace('#!', '');
    } else {
      current = location.pathname + location.search;
    }

    if (current === ctx.canonicalPath) return;
    page.stop();
    ctx.handled = false;
    location.href = ctx.canonicalPath;
  }

  /**
   * Register an exit route on `path` with
   * callback `fn()`, which will be called
   * on the previous context when a new
   * page is visited.
   */
  page.exit = function(path, fn) {
    if (typeof path === 'function') {
      return page.exit('*', path);
    }

    var route = new Route(path);
    for (var i = 1; i < arguments.length; ++i) {
      page.exits.push(route.middleware(arguments[i]));
    }
  };

  /**
   * Remove URL encoding from the given `str`.
   * Accommodates whitespace in both x-www-form-urlencoded
   * and regular percent-encoded form.
   *
   * @param {str} URL component to decode
   */
  function decodeURLEncodedURIComponent(val) {
    if (typeof val !== 'string') { return val; }
    return decodeURLComponents ? decodeURIComponent(val.replace(/\+/g, ' ')) : val;
  }

  /**
   * Initialize a new "request" `Context`
   * with the given `path` and optional initial `state`.
   *
   * @param {String} path
   * @param {Object} state
   * @api public
   */

  function Context(path, state) {
    if ('/' === path[0] && 0 !== path.indexOf(base)) path = base + (hashbang ? '#!' : '') + path;
    var i = path.indexOf('?');

    this.canonicalPath = path;
    this.path = path.replace(base, '') || '/';
    if (hashbang) this.path = this.path.replace('#!', '') || '/';

    this.title = document.title;
    this.state = state || {};
    this.state.path = path;
    this.querystring = ~i ? decodeURLEncodedURIComponent(path.slice(i + 1)) : '';
    this.pathname = decodeURLEncodedURIComponent(~i ? path.slice(0, i) : path);
    this.params = {};

    // fragment
    this.hash = '';
    if (!hashbang) {
      if (!~this.path.indexOf('#')) return;
      var parts = this.path.split('#');
      this.path = parts[0];
      this.hash = decodeURLEncodedURIComponent(parts[1]) || '';
      this.querystring = this.querystring.split('#')[0];
    }
  }

  /**
   * Expose `Context`.
   */

  page.Context = Context;

  /**
   * Push state.
   *
   * @api private
   */

  Context.prototype.pushState = function() {
    page.len++;
    history.pushState(this.state, this.title, hashbang && this.path !== '/' ? '#!' + this.path : this.canonicalPath);
  };

  /**
   * Save the context state.
   *
   * @api public
   */

  Context.prototype.save = function() {
    history.replaceState(this.state, this.title, hashbang && this.path !== '/' ? '#!' + this.path : this.canonicalPath);
  };

  /**
   * Initialize `Route` with the given HTTP `path`,
   * and an array of `callbacks` and `options`.
   *
   * Options:
   *
   *   - `sensitive`    enable case-sensitive routes
   *   - `strict`       enable strict matching for trailing slashes
   *
   * @param {String} path
   * @param {Object} options.
   * @api private
   */

  function Route(path, options) {
    options = options || {};
    this.path = (path === '*') ? '(.*)' : path;
    this.method = 'GET';
    this.regexp = pathtoRegexp(this.path,
      this.keys = [],
      options.sensitive,
      options.strict);
  }

  /**
   * Expose `Route`.
   */

  page.Route = Route;

  /**
   * Return route middleware with
   * the given callback `fn()`.
   *
   * @param {Function} fn
   * @return {Function}
   * @api public
   */

  Route.prototype.middleware = function(fn) {
    var self = this;
    return function(ctx, next) {
      if (self.match(ctx.path, ctx.params)) return fn(ctx, next);
      next();
    };
  };

  /**
   * Check if this route matches `path`, if so
   * populate `params`.
   *
   * @param {String} path
   * @param {Object} params
   * @return {Boolean}
   * @api private
   */

  Route.prototype.match = function(path, params) {
    var keys = this.keys,
      qsIndex = path.indexOf('?'),
      pathname = ~qsIndex ? path.slice(0, qsIndex) : path,
      m = this.regexp.exec(decodeURIComponent(pathname));

    if (!m) return false;

    for (var i = 1, len = m.length; i < len; ++i) {
      var key = keys[i - 1];
      var val = decodeURLEncodedURIComponent(m[i]);
      if (val !== undefined || !(hasOwnProperty.call(params, key.name))) {
        params[key.name] = val;
      }
    }

    return true;
  };


  /**
   * Handle "populate" events.
   */

  var onpopstate = (function () {
    var loaded = false;
    if ('undefined' === typeof window) {
      return;
    }
    if (document.readyState === 'complete') {
      loaded = true;
    } else {
      window.addEventListener('load', function() {
        setTimeout(function() {
          loaded = true;
        }, 0);
      });
    }
    return function onpopstate(e) {
      if (!loaded) return;
      if (e.state) {
        var path = e.state.path;
        page.replace(path, e.state);
      } else {
        page.show(location.pathname + location.hash, undefined, undefined, false);
      }
    };
  })();
  /**
   * Handle "click" events.
   */

  function onclick(e) {

    if (1 !== which(e)) return;

    if (e.metaKey || e.ctrlKey || e.shiftKey) return;
    if (e.defaultPrevented) return;



    // ensure link
    var el = e.target;
    while (el && 'A' !== el.nodeName) el = el.parentNode;
    if (!el || 'A' !== el.nodeName) return;



    // Ignore if tag has
    // 1. "download" attribute
    // 2. rel="external" attribute
    if (el.hasAttribute('download') || el.getAttribute('rel') === 'external') return;

    // ensure non-hash for the same path
    var link = el.getAttribute('href');
    if (!hashbang && el.pathname === location.pathname && (el.hash || '#' === link)) return;



    // Check for mailto: in the href
    if (link && link.indexOf('mailto:') > -1) return;

    // check target
    if (el.target) return;

    // x-origin
    if (!sameOrigin(el.href)) return;



    // rebuild path
    var path = el.pathname + el.search + (el.hash || '');

    // strip leading "/[drive letter]:" on NW.js on Windows
    if (typeof process !== 'undefined' && path.match(/^\/[a-zA-Z]:\//)) {
      path = path.replace(/^\/[a-zA-Z]:\//, '/');
    }

    // same page
    var orig = path;

    if (path.indexOf(base) === 0) {
      path = path.substr(base.length);
    }

    if (hashbang) path = path.replace('#!', '');

    if (base && orig === path) return;

    e.preventDefault();
    page.show(orig);
  }

  /**
   * Event button.
   */

  function which(e) {
    e = e || window.event;
    return null === e.which ? e.button : e.which;
  }

  /**
   * Check if `href` is the same origin.
   */

  function sameOrigin(href) {
    var origin = location.protocol + '//' + location.hostname;
    if (location.port) origin += ':' + location.port;
    return (href && (0 === href.indexOf(origin)));
  }

  page.sameOrigin = sameOrigin;

}).call(this,require('_process'))

},{"_process":1,"path-to-regexp":4}],4:[function(require,module,exports){
var isArray = require('isarray');

/**
 * Expose `pathToRegexp`.
 */
module.exports = pathToRegexp;

/**
 * The main path matching regexp utility.
 *
 * @type {RegExp}
 */
var PATH_REGEXP = new RegExp([
  // Match escaped characters that would otherwise appear in future matches.
  // This allows the user to escape special characters that won't transform.
  '(\\\\.)',
  // Match Express-style parameters and un-named parameters with a prefix
  // and optional suffixes. Matches appear as:
  //
  // "/:test(\\d+)?" => ["/", "test", "\d+", undefined, "?"]
  // "/route(\\d+)" => [undefined, undefined, undefined, "\d+", undefined]
  '([\\/.])?(?:\\:(\\w+)(?:\\(((?:\\\\.|[^)])*)\\))?|\\(((?:\\\\.|[^)])*)\\))([+*?])?',
  // Match regexp special characters that are always escaped.
  '([.+*?=^!:${}()[\\]|\\/])'
].join('|'), 'g');

/**
 * Escape the capturing group by escaping special characters and meaning.
 *
 * @param  {String} group
 * @return {String}
 */
function escapeGroup (group) {
  return group.replace(/([=!:$\/()])/g, '\\$1');
}

/**
 * Attach the keys as a property of the regexp.
 *
 * @param  {RegExp} re
 * @param  {Array}  keys
 * @return {RegExp}
 */
function attachKeys (re, keys) {
  re.keys = keys;
  return re;
}

/**
 * Get the flags for a regexp from the options.
 *
 * @param  {Object} options
 * @return {String}
 */
function flags (options) {
  return options.sensitive ? '' : 'i';
}

/**
 * Pull out keys from a regexp.
 *
 * @param  {RegExp} path
 * @param  {Array}  keys
 * @return {RegExp}
 */
function regexpToRegexp (path, keys) {
  // Use a negative lookahead to match only capturing groups.
  var groups = path.source.match(/\((?!\?)/g);

  if (groups) {
    for (var i = 0; i < groups.length; i++) {
      keys.push({
        name:      i,
        delimiter: null,
        optional:  false,
        repeat:    false
      });
    }
  }

  return attachKeys(path, keys);
}

/**
 * Transform an array into a regexp.
 *
 * @param  {Array}  path
 * @param  {Array}  keys
 * @param  {Object} options
 * @return {RegExp}
 */
function arrayToRegexp (path, keys, options) {
  var parts = [];

  for (var i = 0; i < path.length; i++) {
    parts.push(pathToRegexp(path[i], keys, options).source);
  }

  var regexp = new RegExp('(?:' + parts.join('|') + ')', flags(options));
  return attachKeys(regexp, keys);
}

/**
 * Replace the specific tags with regexp strings.
 *
 * @param  {String} path
 * @param  {Array}  keys
 * @return {String}
 */
function replacePath (path, keys) {
  var index = 0;

  function replace (_, escaped, prefix, key, capture, group, suffix, escape) {
    if (escaped) {
      return escaped;
    }

    if (escape) {
      return '\\' + escape;
    }

    var repeat   = suffix === '+' || suffix === '*';
    var optional = suffix === '?' || suffix === '*';

    keys.push({
      name:      key || index++,
      delimiter: prefix || '/',
      optional:  optional,
      repeat:    repeat
    });

    prefix = prefix ? ('\\' + prefix) : '';
    capture = escapeGroup(capture || group || '[^' + (prefix || '\\/') + ']+?');

    if (repeat) {
      capture = capture + '(?:' + prefix + capture + ')*';
    }

    if (optional) {
      return '(?:' + prefix + '(' + capture + '))?';
    }

    // Basic parameter support.
    return prefix + '(' + capture + ')';
  }

  return path.replace(PATH_REGEXP, replace);
}

/**
 * Normalize the given path string, returning a regular expression.
 *
 * An empty array can be passed in for the keys, which will hold the
 * placeholder key descriptions. For example, using `/user/:id`, `keys` will
 * contain `[{ name: 'id', delimiter: '/', optional: false, repeat: false }]`.
 *
 * @param  {(String|RegExp|Array)} path
 * @param  {Array}                 [keys]
 * @param  {Object}                [options]
 * @return {RegExp}
 */
function pathToRegexp (path, keys, options) {
  keys = keys || [];

  if (!isArray(keys)) {
    options = keys;
    keys = [];
  } else if (!options) {
    options = {};
  }

  if (path instanceof RegExp) {
    return regexpToRegexp(path, keys, options);
  }

  if (isArray(path)) {
    return arrayToRegexp(path, keys, options);
  }

  var strict = options.strict;
  var end = options.end !== false;
  var route = replacePath(path, keys);
  var endsWithSlash = path.charAt(path.length - 1) === '/';

  // In non-strict mode we allow a slash at the end of match. If the path to
  // match already ends with a slash, we remove it for consistency. The slash
  // is valid at the end of a path match, not in the middle. This is important
  // in non-ending mode, where "/test/" shouldn't match "/test//route".
  if (!strict) {
    route = (endsWithSlash ? route.slice(0, -2) : route) + '(?:\\/(?=$))?';
  }

  if (end) {
    route += '$';
  } else {
    // In non-ending mode, we need the capturing groups to match as much as
    // possible by using a positive lookahead to the end or next path segment.
    route += strict && endsWithSlash ? '' : '(?=\\/|$)';
  }

  return attachKeys(new RegExp('^' + route, flags(options)), keys);
}

},{"isarray":5}],5:[function(require,module,exports){
module.exports = Array.isArray || function (arr) {
  return Object.prototype.toString.call(arr) == '[object Array]';
};

},{}],6:[function(require,module,exports){
module.exports = require('./lib/');

},{"./lib/":7}],7:[function(require,module,exports){
// Load modules

var Stringify = require('./stringify');
var Parse = require('./parse');


// Declare internals

var internals = {};


module.exports = {
    stringify: Stringify,
    parse: Parse
};

},{"./parse":8,"./stringify":9}],8:[function(require,module,exports){
// Load modules

var Utils = require('./utils');


// Declare internals

var internals = {
    delimiter: '&',
    depth: 5,
    arrayLimit: 20,
    parameterLimit: 1000,
    strictNullHandling: false
};


internals.parseValues = function (str, options) {

    var obj = {};
    var parts = str.split(options.delimiter, options.parameterLimit === Infinity ? undefined : options.parameterLimit);

    for (var i = 0, il = parts.length; i < il; ++i) {
        var part = parts[i];
        var pos = part.indexOf(']=') === -1 ? part.indexOf('=') : part.indexOf(']=') + 1;

        if (pos === -1) {
            obj[Utils.decode(part)] = '';

            if (options.strictNullHandling) {
                obj[Utils.decode(part)] = null;
            }
        }
        else {
            var key = Utils.decode(part.slice(0, pos));
            var val = Utils.decode(part.slice(pos + 1));

            if (!Object.prototype.hasOwnProperty.call(obj, key)) {
                obj[key] = val;
            }
            else {
                obj[key] = [].concat(obj[key]).concat(val);
            }
        }
    }

    return obj;
};


internals.parseObject = function (chain, val, options) {

    if (!chain.length) {
        return val;
    }

    var root = chain.shift();

    var obj;
    if (root === '[]') {
        obj = [];
        obj = obj.concat(internals.parseObject(chain, val, options));
    }
    else {
        obj = Object.create(null);
        var cleanRoot = root[0] === '[' && root[root.length - 1] === ']' ? root.slice(1, root.length - 1) : root;
        var index = parseInt(cleanRoot, 10);
        var indexString = '' + index;
        if (!isNaN(index) &&
            root !== cleanRoot &&
            indexString === cleanRoot &&
            index >= 0 &&
            (options.parseArrays &&
             index <= options.arrayLimit)) {

            obj = [];
            obj[index] = internals.parseObject(chain, val, options);
        }
        else {
            obj[cleanRoot] = internals.parseObject(chain, val, options);
        }
    }

    return obj;
};


internals.parseKeys = function (key, val, options) {

    if (!key) {
        return;
    }

    // Transform dot notation to bracket notation

    if (options.allowDots) {
        key = key.replace(/\.([^\.\[]+)/g, '[$1]');
    }

    // The regex chunks

    var parent = /^([^\[\]]*)/;
    var child = /(\[[^\[\]]*\])/g;

    // Get the parent

    var segment = parent.exec(key);

    // Stash the parent if it exists

    var keys = [];
    if (segment[1]) {
        keys.push(segment[1]);
    }

    // Loop through children appending to the array until we hit depth

    var i = 0;
    while ((segment = child.exec(key)) !== null && i < options.depth) {

        ++i;
        keys.push(segment[1]);
    }

    // If there's a remainder, just add whatever is left

    if (segment) {
        keys.push('[' + key.slice(segment.index) + ']');
    }

    return internals.parseObject(keys, val, options);
};


module.exports = function (str, options) {

    if (str === '' ||
        str === null ||
        typeof str === 'undefined') {

        return Object.create(null);
    }

    options = options || {};
    options.delimiter = typeof options.delimiter === 'string' || Utils.isRegExp(options.delimiter) ? options.delimiter : internals.delimiter;
    options.depth = typeof options.depth === 'number' ? options.depth : internals.depth;
    options.arrayLimit = typeof options.arrayLimit === 'number' ? options.arrayLimit : internals.arrayLimit;
    options.parseArrays = options.parseArrays !== false;
    options.allowDots = options.allowDots !== false;
    options.parameterLimit = typeof options.parameterLimit === 'number' ? options.parameterLimit : internals.parameterLimit;
    options.strictNullHandling = typeof options.strictNullHandling === 'boolean' ? options.strictNullHandling : internals.strictNullHandling;


    var tempObj = typeof str === 'string' ? internals.parseValues(str, options) : str;
    var obj = Object.create(null);

    // Iterate over the keys and setup the new object

    var keys = Object.keys(tempObj);
    for (var i = 0, il = keys.length; i < il; ++i) {
        var key = keys[i];
        var newObj = internals.parseKeys(key, tempObj[key], options);
        obj = Utils.merge(obj, newObj);
    }

    return Utils.compact(obj);
};

},{"./utils":10}],9:[function(require,module,exports){
// Load modules

var Utils = require('./utils');


// Declare internals

var internals = {
    delimiter: '&',
    arrayPrefixGenerators: {
        brackets: function (prefix, key) {

            return prefix + '[]';
        },
        indices: function (prefix, key) {

            return prefix + '[' + key + ']';
        },
        repeat: function (prefix, key) {

            return prefix;
        }
    },
    strictNullHandling: false
};


internals.stringify = function (obj, prefix, generateArrayPrefix, strictNullHandling, filter) {

    if (typeof filter === 'function') {
        obj = filter(prefix, obj);
    }
    else if (Utils.isBuffer(obj)) {
        obj = obj.toString();
    }
    else if (obj instanceof Date) {
        obj = obj.toISOString();
    }
    else if (obj === null) {
        if (strictNullHandling) {
            return Utils.encode(prefix);
        }

        obj = '';
    }

    if (typeof obj === 'string' ||
        typeof obj === 'number' ||
        typeof obj === 'boolean') {

        return [Utils.encode(prefix) + '=' + Utils.encode(obj)];
    }

    var values = [];

    if (typeof obj === 'undefined') {
        return values;
    }

    var objKeys = Array.isArray(filter) ? filter : Object.keys(obj);
    for (var i = 0, il = objKeys.length; i < il; ++i) {
        var key = objKeys[i];

        if (Array.isArray(obj)) {
            values = values.concat(internals.stringify(obj[key], generateArrayPrefix(prefix, key), generateArrayPrefix, strictNullHandling, filter));
        }
        else {
            values = values.concat(internals.stringify(obj[key], prefix + '[' + key + ']', generateArrayPrefix, strictNullHandling, filter));
        }
    }

    return values;
};


module.exports = function (obj, options) {

    options = options || {};
    var delimiter = typeof options.delimiter === 'undefined' ? internals.delimiter : options.delimiter;
    var strictNullHandling = typeof options.strictNullHandling === 'boolean' ? options.strictNullHandling : internals.strictNullHandling;
    var objKeys;
    var filter;
    if (typeof options.filter === 'function') {
        filter = options.filter;
        obj = filter('', obj);
    }
    else if (Array.isArray(options.filter)) {
        objKeys = filter = options.filter;
    }

    var keys = [];

    if (typeof obj !== 'object' ||
        obj === null) {

        return '';
    }

    var arrayFormat;
    if (options.arrayFormat in internals.arrayPrefixGenerators) {
        arrayFormat = options.arrayFormat;
    }
    else if ('indices' in options) {
        arrayFormat = options.indices ? 'indices' : 'repeat';
    }
    else {
        arrayFormat = 'indices';
    }

    var generateArrayPrefix = internals.arrayPrefixGenerators[arrayFormat];

    if (!objKeys) {
        objKeys = Object.keys(obj);
    }
    for (var i = 0, il = objKeys.length; i < il; ++i) {
        var key = objKeys[i];
        keys = keys.concat(internals.stringify(obj[key], key, generateArrayPrefix, strictNullHandling, filter));
    }

    return keys.join(delimiter);
};

},{"./utils":10}],10:[function(require,module,exports){
// Load modules


// Declare internals

var internals = {};
internals.hexTable = new Array(256);
for (var i = 0; i < 256; ++i) {
    internals.hexTable[i] = '%' + ((i < 16 ? '0' : '') + i.toString(16)).toUpperCase();
}


exports.arrayToObject = function (source) {

    var obj = Object.create(null);
    for (var i = 0, il = source.length; i < il; ++i) {
        if (typeof source[i] !== 'undefined') {

            obj[i] = source[i];
        }
    }

    return obj;
};


exports.merge = function (target, source) {

    if (!source) {
        return target;
    }

    if (typeof source !== 'object') {
        if (Array.isArray(target)) {
            target.push(source);
        }
        else if (typeof target === 'object') {
            target[source] = true;
        }
        else {
            target = [target, source];
        }

        return target;
    }

    if (typeof target !== 'object') {
        target = [target].concat(source);
        return target;
    }

    if (Array.isArray(target) &&
        !Array.isArray(source)) {

        target = exports.arrayToObject(target);
    }

    var keys = Object.keys(source);
    for (var k = 0, kl = keys.length; k < kl; ++k) {
        var key = keys[k];
        var value = source[key];

        if (!target[key]) {
            target[key] = value;
        }
        else {
            target[key] = exports.merge(target[key], value);
        }
    }

    return target;
};


exports.decode = function (str) {

    try {
        return decodeURIComponent(str.replace(/\+/g, ' '));
    } catch (e) {
        return str;
    }
};

exports.encode = function (str) {

    // This code was originally written by Brian White (mscdex) for the io.js core querystring library.
    // It has been adapted here for stricter adherence to RFC 3986
    if (str.length === 0) {
        return str;
    }

    if (typeof str !== 'string') {
        str = '' + str;
    }

    var out = '';
    for (var i = 0, il = str.length; i < il; ++i) {
        var c = str.charCodeAt(i);

        if (c === 0x2D || // -
            c === 0x2E || // .
            c === 0x5F || // _
            c === 0x7E || // ~
            (c >= 0x30 && c <= 0x39) || // 0-9
            (c >= 0x41 && c <= 0x5A) || // a-z
            (c >= 0x61 && c <= 0x7A)) { // A-Z

            out += str[i];
            continue;
        }

        if (c < 0x80) {
            out += internals.hexTable[c];
            continue;
        }

        if (c < 0x800) {
            out += internals.hexTable[0xC0 | (c >> 6)] + internals.hexTable[0x80 | (c & 0x3F)];
            continue;
        }

        if (c < 0xD800 || c >= 0xE000) {
            out += internals.hexTable[0xE0 | (c >> 12)] + internals.hexTable[0x80 | ((c >> 6) & 0x3F)] + internals.hexTable[0x80 | (c & 0x3F)];
            continue;
        }

        ++i;
        c = 0x10000 + (((c & 0x3FF) << 10) | (str.charCodeAt(i) & 0x3FF));
        out += internals.hexTable[0xF0 | (c >> 18)] + internals.hexTable[0x80 | ((c >> 12) & 0x3F)] + internals.hexTable[0x80 | ((c >> 6) & 0x3F)] + internals.hexTable[0x80 | (c & 0x3F)];
    }

    return out;
};

exports.compact = function (obj, refs) {

    if (typeof obj !== 'object' ||
        obj === null) {

        return obj;
    }

    refs = refs || [];
    var lookup = refs.indexOf(obj);
    if (lookup !== -1) {
        return refs[lookup];
    }

    refs.push(obj);

    if (Array.isArray(obj)) {
        var compacted = [];

        for (var i = 0, il = obj.length; i < il; ++i) {
            if (typeof obj[i] !== 'undefined') {
                compacted.push(obj[i]);
            }
        }

        return compacted;
    }

    var keys = Object.keys(obj);
    for (i = 0, il = keys.length; i < il; ++i) {
        var key = keys[i];
        obj[key] = exports.compact(obj[key], refs);
    }

    return obj;
};


exports.isRegExp = function (obj) {

    return Object.prototype.toString.call(obj) === '[object RegExp]';
};


exports.isBuffer = function (obj) {

    if (obj === null ||
        typeof obj === 'undefined') {

        return false;
    }

    return !!(obj.constructor &&
              obj.constructor.isBuffer &&
              obj.constructor.isBuffer(obj));
};

},{}]},{},[2])
//# sourceMappingURL=local-test:meteorhacks:flow-router/client.browserify.js
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:flow-router/client/triggers.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// a set of utility functions for triggers                                                                            // 1
                                                                                                                      // 2
Triggers = {};                                                                                                        // 3
                                                                                                                      // 4
// Apply filters for a set of triggers                                                                                // 5
// @triggers - a set of triggers                                                                                      // 6
// @filter - filter with array fileds with `only` and `except`                                                        // 7
//           support only either `only` or `except`, but not both                                                     // 8
Triggers.applyFilters = function(triggers, filter) {                                                                  // 9
  if(!(triggers instanceof Array)) {                                                                                  // 10
    triggers = [triggers];                                                                                            // 11
  }                                                                                                                   // 12
                                                                                                                      // 13
  if(!filter) {                                                                                                       // 14
    return triggers;                                                                                                  // 15
  }                                                                                                                   // 16
                                                                                                                      // 17
  if(filter.only && filter.except) {                                                                                  // 18
    throw new Error("Triggers don't support only and except filters at once");                                        // 19
  }                                                                                                                   // 20
                                                                                                                      // 21
  if(filter.only && !(filter.only instanceof Array)) {                                                                // 22
    throw new Error("only filters needs to be an array");                                                             // 23
  }                                                                                                                   // 24
                                                                                                                      // 25
  if(filter.except && !(filter.except instanceof Array)) {                                                            // 26
    throw new Error("except filters needs to be an array");                                                           // 27
  }                                                                                                                   // 28
                                                                                                                      // 29
  if(filter.only) {                                                                                                   // 30
    return Triggers.createRouteBoundTriggers(triggers, filter.only);                                                  // 31
  }                                                                                                                   // 32
                                                                                                                      // 33
  if(filter.except) {                                                                                                 // 34
    return Triggers.createRouteBoundTriggers(triggers, filter.except, true);                                          // 35
  }                                                                                                                   // 36
                                                                                                                      // 37
  throw new Error("Provided a filter but not supported");                                                             // 38
};                                                                                                                    // 39
                                                                                                                      // 40
//  create triggers by bounding them to a set of route names                                                          // 41
//  @triggers - a set of triggers                                                                                     // 42
//  @names - list of route names to be bound (trigger runs only for these names)                                      // 43
//  @negate - negate the result (triggers won't run for above names)                                                  // 44
Triggers.createRouteBoundTriggers = function(triggers, names, negate) {                                               // 45
  var namesMap = {};                                                                                                  // 46
  _.each(names, function(name) {                                                                                      // 47
    namesMap[name] = true;                                                                                            // 48
  });                                                                                                                 // 49
                                                                                                                      // 50
  var filteredTriggers = _.map(triggers, function(originalTrigger) {                                                  // 51
    var modifiedTrigger = function(context, next) {                                                                   // 52
      var routeName = context.route.name;                                                                             // 53
      var matched = (namesMap[routeName])? 1: -1;                                                                     // 54
      matched = (negate)? matched * -1 : matched;                                                                     // 55
                                                                                                                      // 56
      if(matched === 1) {                                                                                             // 57
        originalTrigger(context, next);                                                                               // 58
      }                                                                                                               // 59
    };                                                                                                                // 60
    return modifiedTrigger;                                                                                           // 61
  });                                                                                                                 // 62
                                                                                                                      // 63
  return filteredTriggers;                                                                                            // 64
};                                                                                                                    // 65
                                                                                                                      // 66
//  run triggers and abort if redirected                                                                              // 67
//  @triggers - a set of triggers                                                                                     // 68
//  @context - context we need to pass (it must have the route)                                                       // 69
//  @redirectFn - function which used to redirect                                                                     // 70
//  @after - called after if only all the triggers runs                                                               // 71
Triggers.runTriggers = function(triggers, context, redirectFn, after) {                                               // 72
  var abort = false;                                                                                                  // 73
  var inCurrentLoop = true;                                                                                           // 74
  var alreadyRedirected = false;                                                                                      // 75
                                                                                                                      // 76
  for(var lc=0; lc<triggers.length; lc++) {                                                                           // 77
    var trigger = triggers[lc];                                                                                       // 78
    trigger(context, doRedirect);                                                                                     // 79
                                                                                                                      // 80
    if(abort) {                                                                                                       // 81
      return;                                                                                                         // 82
    }                                                                                                                 // 83
  }                                                                                                                   // 84
                                                                                                                      // 85
  // mark that, we've exceeds the currentEventloop for                                                                // 86
  // this set of triggers.                                                                                            // 87
  inCurrentLoop = false;                                                                                              // 88
  after();                                                                                                            // 89
                                                                                                                      // 90
  function doRedirect(url, params, queryParams) {                                                                     // 91
    if(alreadyRedirected) {                                                                                           // 92
      throw new Error("already redirected");                                                                          // 93
    }                                                                                                                 // 94
                                                                                                                      // 95
    if(!inCurrentLoop) {                                                                                              // 96
      throw new Error("redirect needs to be done in sync");                                                           // 97
    }                                                                                                                 // 98
                                                                                                                      // 99
    if(!url) {                                                                                                        // 100
      throw new Error("trigger redirect requires an URL");                                                            // 101
    }                                                                                                                 // 102
                                                                                                                      // 103
    abort = true;                                                                                                     // 104
    alreadyRedirected = true;                                                                                         // 105
    redirectFn(url, params, queryParams);                                                                             // 106
  }                                                                                                                   // 107
};                                                                                                                    // 108
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:flow-router/client/router.js                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Router = function () {                                                                                                // 1
  var self = this;                                                                                                    // 2
  this.globals = [];                                                                                                  // 3
  this.subscriptions = Function.prototype;                                                                            // 4
                                                                                                                      // 5
  this._tracker = this._buildTracker();                                                                               // 6
  this._current = {};                                                                                                 // 7
                                                                                                                      // 8
  // tracks the current path change                                                                                   // 9
  this._onEveryPath = new Tracker.Dependency();                                                                       // 10
                                                                                                                      // 11
  this._globalRoute = new Route(this);                                                                                // 12
                                                                                                                      // 13
  // if _askedToWait is true. We don't automatically start the router                                                 // 14
  // in Meteor.startup callback. (see client/_init.js)                                                                // 15
  // Instead user need to call `.initialize()                                                                         // 16
  this._askedToWait = false;                                                                                          // 17
  this._initialized = false;                                                                                          // 18
  this._triggersEnter = [];                                                                                           // 19
  this._triggersExit = [];                                                                                            // 20
  this._middleware = [];                                                                                              // 21
  this._routes = [];                                                                                                  // 22
  this._routesMap = {};                                                                                               // 23
  this._updateCallbacks();                                                                                            // 24
  this.notFound = this.notfound = null;                                                                               // 25
  // indicate it's okay (or not okay) to run the tracker                                                              // 26
  // when doing subscriptions                                                                                         // 27
  // using a number and increment it help us to support FlowRouter.go()                                               // 28
  // and legitimate reruns inside tracker on the same event loop.                                                     // 29
  // this is a solution for #145                                                                                      // 30
  this.safeToRun = 0;                                                                                                 // 31
                                                                                                                      // 32
  this.env = {                                                                                                        // 33
    replaceState: new Meteor.EnvironmentVariable(),                                                                   // 34
    reload: new Meteor.EnvironmentVariable(),                                                                         // 35
    trailingSlash: new Meteor.EnvironmentVariable()                                                                   // 36
  };                                                                                                                  // 37
                                                                                                                      // 38
  // redirect function used inside triggers                                                                           // 39
  this._redirectFn = function(pathDef, fields, queryParams) {                                                         // 40
    self.withReplaceState(function() {                                                                                // 41
      self.go(pathDef, fields, queryParams);                                                                          // 42
    });                                                                                                               // 43
  };                                                                                                                  // 44
  this._initTriggersAPI();                                                                                            // 45
};                                                                                                                    // 46
                                                                                                                      // 47
Router.prototype.route = function(path, options, group) {                                                             // 48
  if (!/^\/.*/.test(path)) {                                                                                          // 49
    var message = "route's path must start with '/'";                                                                 // 50
    throw new Error(message);                                                                                         // 51
  }                                                                                                                   // 52
                                                                                                                      // 53
  options = options || {};                                                                                            // 54
  var self = this;                                                                                                    // 55
  var route = new Route(this, path, options, group);                                                                  // 56
                                                                                                                      // 57
  // calls when the page route being activates                                                                        // 58
  route._actionHandle = function (context, next) {                                                                    // 59
    var oldRoute = self._current.route;                                                                               // 60
    var queryParams = self._qs.parse(context.querystring);                                                            // 61
    // _qs.parse() gives us a object without prototypes,                                                              // 62
    // created with Object.create(null)                                                                               // 63
    // Meteor's check doesn't play nice with it.                                                                      // 64
    // So, we need to fix it by cloning it.                                                                           // 65
    // see more: https://github.com/meteorhacks/flow-router/issues/164                                                // 66
    queryParams = JSON.parse(JSON.stringify(queryParams));                                                            // 67
                                                                                                                      // 68
    self._current = {                                                                                                 // 69
      path: context.path,                                                                                             // 70
      context: context,                                                                                               // 71
      params: context.params,                                                                                         // 72
      queryParams: queryParams,                                                                                       // 73
      route: route,                                                                                                   // 74
      oldRoute: oldRoute                                                                                              // 75
    };                                                                                                                // 76
                                                                                                                      // 77
    // to backward compatibility                                                                                      // 78
    self._current.params.query = self._current.queryParams;                                                           // 79
                                                                                                                      // 80
    // we need to invalidate if all the triggers have been completed                                                  // 81
    // if not that means, we've been redirected to another path                                                       // 82
    // then we don't need to invalidate                                                                               // 83
    var afterAllTriggersRan = function() {                                                                            // 84
      self._invalidateTracker();                                                                                      // 85
    };                                                                                                                // 86
                                                                                                                      // 87
    var triggers = self._triggersEnter.concat(route._triggersEnter);                                                  // 88
    Triggers.runTriggers(                                                                                             // 89
      triggers,                                                                                                       // 90
      self._current,                                                                                                  // 91
      self._redirectFn,                                                                                               // 92
      afterAllTriggersRan                                                                                             // 93
    );                                                                                                                // 94
  };                                                                                                                  // 95
                                                                                                                      // 96
  // calls when you exit from the page js route                                                                       // 97
  route._exitHandle = function(context, next) {                                                                       // 98
    var triggers = self._triggersExit.concat(route._triggersExit);                                                    // 99
    Triggers.runTriggers(                                                                                             // 100
      triggers,                                                                                                       // 101
      self._current,                                                                                                  // 102
      self._redirectFn,                                                                                               // 103
      next                                                                                                            // 104
    );                                                                                                                // 105
  };                                                                                                                  // 106
                                                                                                                      // 107
  this._routes.push(route);                                                                                           // 108
  if (options.name) {                                                                                                 // 109
    this._routesMap[options.name] = route;                                                                            // 110
  }                                                                                                                   // 111
                                                                                                                      // 112
  this._updateCallbacks();                                                                                            // 113
                                                                                                                      // 114
  return route;                                                                                                       // 115
};                                                                                                                    // 116
                                                                                                                      // 117
Router.prototype.group = function(options) {                                                                          // 118
  return new Group(this, options);                                                                                    // 119
};                                                                                                                    // 120
                                                                                                                      // 121
Router.prototype.path = function(pathDef, fields, queryParams) {                                                      // 122
  if (this._routesMap[pathDef]) {                                                                                     // 123
    pathDef = this._routesMap[pathDef].path;                                                                          // 124
  }                                                                                                                   // 125
                                                                                                                      // 126
  fields = fields || {};                                                                                              // 127
  var regExp = /(:[\w\(\)\\\+\*\.\?]+)+/g;                                                                            // 128
  var path = pathDef.replace(regExp, function(key) {                                                                  // 129
    var firstRegexpChar = key.indexOf("(");                                                                           // 130
    // get the content behind : and (\\d+/)                                                                           // 131
    key = key.substring(1, (firstRegexpChar > 0)? firstRegexpChar: undefined);                                        // 132
    // remove +?*                                                                                                     // 133
    key = key.replace(/[\+\*\?]+/g, "");                                                                              // 134
                                                                                                                      // 135
    // this is to allow page js to keep the custom characters as it is                                                // 136
    // we need to encode 2 times otherwise "/" char does not work properly                                            // 137
    // So, in that case, when I includes "/" it will think it's a part of the                                         // 138
    // route. encoding 2times fixes it                                                                                // 139
    return encodeURIComponent(encodeURIComponent(fields[key] || ""));                                                 // 140
  });                                                                                                                 // 141
                                                                                                                      // 142
  path = path.replace(/\/\/+/g, "/"); // Replace multiple slashes with single slash                                   // 143
                                                                                                                      // 144
  // remove trailing slash                                                                                            // 145
  // but keep the root slash if it's the only one                                                                     // 146
  path = path.match(/^\/{1}$/) ? path: path.replace(/\/$/, "");                                                       // 147
                                                                                                                      // 148
  // explictly asked to add a trailing slash                                                                          // 149
  if(this.env.trailingSlash.get() && _.last(path) !== "/") {                                                          // 150
    path += "/";                                                                                                      // 151
  }                                                                                                                   // 152
                                                                                                                      // 153
  var strQueryParams = this._qs.stringify(queryParams || {});                                                         // 154
  if(strQueryParams) {                                                                                                // 155
    path += "?" + strQueryParams;                                                                                     // 156
  }                                                                                                                   // 157
                                                                                                                      // 158
  return path;                                                                                                        // 159
};                                                                                                                    // 160
                                                                                                                      // 161
Router.prototype.go = function(pathDef, fields, queryParams) {                                                        // 162
  var path = this.path(pathDef, fields, queryParams);                                                                 // 163
                                                                                                                      // 164
  var useReplaceState = this.env.replaceState.get();                                                                  // 165
  if(useReplaceState) {                                                                                               // 166
    this._page.replace(path);                                                                                         // 167
  } else {                                                                                                            // 168
    this._page(path);                                                                                                 // 169
  }                                                                                                                   // 170
};                                                                                                                    // 171
                                                                                                                      // 172
Router.prototype.reload = function() {                                                                                // 173
  var self = this;                                                                                                    // 174
                                                                                                                      // 175
  self.env.reload.withValue(true, function() {                                                                        // 176
    self._page.replace(self._current.path);                                                                           // 177
  });                                                                                                                 // 178
};                                                                                                                    // 179
                                                                                                                      // 180
Router.prototype.redirect = function(path) {                                                                          // 181
  this._page.redirect(path);                                                                                          // 182
};                                                                                                                    // 183
                                                                                                                      // 184
Router.prototype.setParams = function(newParams) {                                                                    // 185
  if(!this._current.route) {return false;}                                                                            // 186
                                                                                                                      // 187
  var pathDef = this._current.route.path;                                                                             // 188
  var existingParams = this._current.params;                                                                          // 189
  var params = {};                                                                                                    // 190
  _.each(_.keys(existingParams), function(key) {                                                                      // 191
    params[key] = existingParams[key];                                                                                // 192
  });                                                                                                                 // 193
                                                                                                                      // 194
  params = _.extend(params, newParams);                                                                               // 195
  var queryParams = this._current.queryParams;                                                                        // 196
                                                                                                                      // 197
  this.go(pathDef, params, queryParams);                                                                              // 198
  return true;                                                                                                        // 199
};                                                                                                                    // 200
                                                                                                                      // 201
Router.prototype.setQueryParams = function(newParams) {                                                               // 202
  if(!this._current.route) {return false;}                                                                            // 203
                                                                                                                      // 204
  var queryParams = _.clone(this._current.queryParams);                                                               // 205
  _.extend(queryParams, newParams);                                                                                   // 206
                                                                                                                      // 207
  for (var k in queryParams) {                                                                                        // 208
    if (queryParams[k] === null || queryParams[k] === undefined) {                                                    // 209
      delete queryParams[k];                                                                                          // 210
    }                                                                                                                 // 211
  }                                                                                                                   // 212
                                                                                                                      // 213
  var pathDef = this._current.route.path;                                                                             // 214
  var params = this._current.params;                                                                                  // 215
  this.go(pathDef, params, queryParams);                                                                              // 216
  return true;                                                                                                        // 217
};                                                                                                                    // 218
                                                                                                                      // 219
// .current is not reactive                                                                                           // 220
// This is by design. use .getParam() instead                                                                         // 221
// If you really need to watch the path change, use .watchPathChange()                                                // 222
Router.prototype.current = function() {                                                                               // 223
  return this._current;                                                                                               // 224
};                                                                                                                    // 225
                                                                                                                      // 226
Router.prototype.reactiveCurrent = function() {                                                                       // 227
  var warnMessage =                                                                                                   // 228
    ".reactiveCurrent() is deprecated. " +                                                                            // 229
    "Use .watchPathChange() instead";                                                                                 // 230
  console.warn(warnMessage);                                                                                          // 231
                                                                                                                      // 232
  this.watchPathChange();                                                                                             // 233
  return this.current();                                                                                              // 234
};                                                                                                                    // 235
                                                                                                                      // 236
// Implementing Reactive APIs                                                                                         // 237
var reactiveApis = [                                                                                                  // 238
  'getParam', 'getQueryParam',                                                                                        // 239
  'getRouteName', 'watchPathChange'                                                                                   // 240
];                                                                                                                    // 241
reactiveApis.forEach(function(api) {                                                                                  // 242
  Router.prototype[api] = function(arg1) {                                                                            // 243
    // when this is calling, there may not be any route initiated                                                     // 244
    // so we need to handle it                                                                                        // 245
    var currentRoute = this._current.route;                                                                           // 246
    if(!currentRoute) {                                                                                               // 247
      this._onEveryPath.depend();                                                                                     // 248
      return;                                                                                                         // 249
    }                                                                                                                 // 250
                                                                                                                      // 251
    // currently, there is only one argument. If we've more let's add more args                                       // 252
    // this is not clean code, but better in performance                                                              // 253
    return currentRoute[api].call(currentRoute, arg1);                                                                // 254
  };                                                                                                                  // 255
});                                                                                                                   // 256
                                                                                                                      // 257
Router.prototype.middleware = function(middlewareFn) {                                                                // 258
  console.warn("'middleware' is deprecated. Use 'triggers' instead");                                                 // 259
  var self = this;                                                                                                    // 260
  var mw = function(ctx, next) {                                                                                      // 261
    // make sure middlewars run after Meteor has been initialized                                                     // 262
    // this is very important for specially for fast render and Meteor.user()                                         // 263
    // availability                                                                                                   // 264
    Meteor.startup(function() {                                                                                       // 265
      middlewareFn(ctx.pathname, processNext);                                                                        // 266
    });                                                                                                               // 267
                                                                                                                      // 268
    function processNext(path) {                                                                                      // 269
      if(path) {                                                                                                      // 270
        return self._page.redirect(path);                                                                             // 271
      }                                                                                                               // 272
      next();                                                                                                         // 273
    }                                                                                                                 // 274
  };                                                                                                                  // 275
                                                                                                                      // 276
  this._middleware.push(mw);                                                                                          // 277
  this._updateCallbacks();                                                                                            // 278
  return this;                                                                                                        // 279
};                                                                                                                    // 280
                                                                                                                      // 281
Router.prototype.ready = function() {                                                                                 // 282
  console.warn("'FlowRouter.ready()' is deprecated. Use 'FlowRouter.subsReady()' instead");                           // 283
  return this.subsReady.apply(this, arguments);                                                                       // 284
};                                                                                                                    // 285
                                                                                                                      // 286
Router.prototype.subsReady = function() {                                                                             // 287
  var callback = null;                                                                                                // 288
  var args = _.toArray(arguments);                                                                                    // 289
                                                                                                                      // 290
  if (typeof _.last(args) === "function") {                                                                           // 291
    callback = args.pop();                                                                                            // 292
  }                                                                                                                   // 293
                                                                                                                      // 294
  var currentRoute = this.current().route;                                                                            // 295
  var globalRoute = this._globalRoute;                                                                                // 296
                                                                                                                      // 297
  // we need to depend for every route change and                                                                     // 298
  // rerun subscriptions to check the ready state                                                                     // 299
  this._onEveryPath.depend();                                                                                         // 300
                                                                                                                      // 301
  if(!currentRoute) {                                                                                                 // 302
    return false;                                                                                                     // 303
  }                                                                                                                   // 304
                                                                                                                      // 305
  var subscriptions;                                                                                                  // 306
  if(args.length === 0) {                                                                                             // 307
    subscriptions = _.values(globalRoute.getAllSubscriptions());                                                      // 308
    subscriptions = subscriptions.concat(_.values(currentRoute.getAllSubscriptions()));                               // 309
  } else {                                                                                                            // 310
    subscriptions = _.map(args, function(subName) {                                                                   // 311
      return globalRoute.getSubscription(subName) || currentRoute.getSubscription(subName);                           // 312
    });                                                                                                               // 313
  }                                                                                                                   // 314
                                                                                                                      // 315
  var isReady = function() {                                                                                          // 316
    var ready =  _.every(subscriptions, function(sub) {                                                               // 317
      return sub && sub.ready();                                                                                      // 318
    });                                                                                                               // 319
                                                                                                                      // 320
    return ready;                                                                                                     // 321
  };                                                                                                                  // 322
                                                                                                                      // 323
  if (callback) {                                                                                                     // 324
    Tracker.autorun(function(c) {                                                                                     // 325
      if (isReady()) {                                                                                                // 326
        callback();                                                                                                   // 327
        c.stop();                                                                                                     // 328
      }                                                                                                               // 329
    });                                                                                                               // 330
  } else {                                                                                                            // 331
    return isReady();                                                                                                 // 332
  }                                                                                                                   // 333
};                                                                                                                    // 334
                                                                                                                      // 335
Router.prototype.withReplaceState = function(fn) {                                                                    // 336
  return this.env.replaceState.withValue(true, fn);                                                                   // 337
};                                                                                                                    // 338
                                                                                                                      // 339
Router.prototype.withTrailingSlash = function(fn) {                                                                   // 340
  return this.env.trailingSlash.withValue(true, fn);                                                                  // 341
};                                                                                                                    // 342
                                                                                                                      // 343
Router.prototype._notfoundRoute = function(context) {                                                                 // 344
  this._current = {                                                                                                   // 345
    path: context.path,                                                                                               // 346
    context: context,                                                                                                 // 347
    params: [],                                                                                                       // 348
    queryParams: {},                                                                                                  // 349
  };                                                                                                                  // 350
                                                                                                                      // 351
  // XXX this.notfound kept for backwards compatibility                                                               // 352
  this.notFound = this.notFound || this.notfound;                                                                     // 353
  if(!this.notFound) {                                                                                                // 354
    console.error("There is no route for the path:", context.path);                                                   // 355
    return;                                                                                                           // 356
  }                                                                                                                   // 357
                                                                                                                      // 358
  this._current.route = new Route(this, "*", this.notFound);                                                          // 359
  this._invalidateTracker();                                                                                          // 360
};                                                                                                                    // 361
                                                                                                                      // 362
Router.prototype.initialize = function() {                                                                            // 363
  if(this._initialized) {                                                                                             // 364
    throw new Error("FlowRouter is already initialized");                                                             // 365
  }                                                                                                                   // 366
                                                                                                                      // 367
  var self = this;                                                                                                    // 368
  this._updateCallbacks();                                                                                            // 369
                                                                                                                      // 370
  // Implementing idempotent routing                                                                                  // 371
  // by overriding page.js`s "show" method.                                                                           // 372
  // Why?                                                                                                             // 373
  // It is impossible to bypass exit triggers,                                                                        // 374
  // becuase they execute before the handler and                                                                      // 375
  // can not know what the next path is, inside exit trigger.                                                         // 376
  //                                                                                                                  // 377
  // we need override both show, replace to make this work                                                            // 378
  // since we use redirect when we are talking about withReplaceState                                                 // 379
  _.each(['show', 'replace'], function(fnName) {                                                                      // 380
    var original = self._page[fnName];                                                                                // 381
    self._page[fnName] = function(path, state, dispatch, push) {                                                      // 382
      var reload = self.env.reload.get();                                                                             // 383
      if (!reload && self._current.path === path) {                                                                   // 384
        return;                                                                                                       // 385
      }                                                                                                               // 386
                                                                                                                      // 387
      original.call(this, path, state, dispatch, push);                                                               // 388
    };                                                                                                                // 389
  });                                                                                                                 // 390
                                                                                                                      // 391
  // this is very ugly part of pagejs and it does decoding few times                                                  // 392
  // in unpredicatable manner. See #168                                                                               // 393
  // this is the default behaviour and we need keep it like that                                                      // 394
  // we are doing a hack. see .path()                                                                                 // 395
  this._page({decodeURLComponents: true});                                                                            // 396
  this._initialized = true;                                                                                           // 397
};                                                                                                                    // 398
                                                                                                                      // 399
Router.prototype._buildTracker = function() {                                                                         // 400
  var self = this;                                                                                                    // 401
                                                                                                                      // 402
  // main autorun function                                                                                            // 403
  var tracker = Tracker.autorun(function () {                                                                         // 404
    if(!self._current || !self._current.route) {                                                                      // 405
      return;                                                                                                         // 406
    }                                                                                                                 // 407
                                                                                                                      // 408
    // see the definition of `this._processingContexts`                                                               // 409
    var currentContext = self._current;                                                                               // 410
    var route = currentContext.route;                                                                                 // 411
    var path = currentContext.path;                                                                                   // 412
                                                                                                                      // 413
    if(self.safeToRun === 0) {                                                                                        // 414
      var message =                                                                                                   // 415
        "You can't use reactive data sources like Session" +                                                          // 416
        " inside the `.subscriptions` method!";                                                                       // 417
      throw new Error(message);                                                                                       // 418
    }                                                                                                                 // 419
                                                                                                                      // 420
    // We need to run subscriptions inside a Tracker                                                                  // 421
    // to stop subs when switching between routes                                                                     // 422
    // But we don't need to run this tracker with                                                                     // 423
    // other reactive changes inside the .subscription method                                                         // 424
    // We tackle this with the `safeToRun` variable                                                                   // 425
    self._globalRoute.clearSubscriptions();                                                                           // 426
    self.subscriptions.call(self._globalRoute, path);                                                                 // 427
    route.callSubscriptions(currentContext);                                                                          // 428
                                                                                                                      // 429
    // otherwise, computations inside action will trigger to re-run                                                   // 430
    // this computation. which we do not need.                                                                        // 431
    Tracker.nonreactive(function() {                                                                                  // 432
      var isRouteChange = currentContext.oldRoute !== currentContext.route;                                           // 433
      var isFirstRoute = !currentContext.oldRoute;                                                                    // 434
      // first route is not a route change                                                                            // 435
      if(isFirstRoute) {                                                                                              // 436
        isRouteChange = false;                                                                                        // 437
      }                                                                                                               // 438
                                                                                                                      // 439
      currentContext.route.registerRouteChange(currentContext, isRouteChange);                                        // 440
      route.callAction(currentContext);                                                                               // 441
                                                                                                                      // 442
      Tracker.afterFlush(function() {                                                                                 // 443
        self._onEveryPath.changed();                                                                                  // 444
        if(isRouteChange) {                                                                                           // 445
          // We need to trigger that route (definition itself) has changed.                                           // 446
          // So, we need to re-run all the register callbacks to current route                                        // 447
          // This is pretty important, otherwise tracker                                                              // 448
          // can't identify new route's items                                                                         // 449
                                                                                                                      // 450
          // We also need to afterFlush, otherwise this will re-run                                                   // 451
          // helpers on templates which are marked for destroying                                                     // 452
          currentContext.oldRoute.registerRouteClose();                                                               // 453
        }                                                                                                             // 454
      });                                                                                                             // 455
    });                                                                                                               // 456
                                                                                                                      // 457
    self.safeToRun--;                                                                                                 // 458
  });                                                                                                                 // 459
                                                                                                                      // 460
  return tracker;                                                                                                     // 461
};                                                                                                                    // 462
                                                                                                                      // 463
Router.prototype._invalidateTracker = function() {                                                                    // 464
  var self = this;                                                                                                    // 465
  this.safeToRun++;                                                                                                   // 466
  this._tracker.invalidate();                                                                                         // 467
  // After the invalidation we need to flush to make changes imediately                                               // 468
  // otherwise, we have face some issues context mix-maches and so on.                                                // 469
  // But there are some cases we can't flush. So we need to ready for that.                                           // 470
                                                                                                                      // 471
  // we clearly know, we can't flush inside an autorun                                                                // 472
  // this may leads some issues on flow-routing                                                                       // 473
  // we may need to do some warning                                                                                   // 474
  if(!Tracker.currentComputation) {                                                                                   // 475
    // Still there are some cases where we can't flush                                                                // 476
    //  eg:- when there is a flush currently                                                                          // 477
    // But we've no public API or hacks to get that state                                                             // 478
    // So, this is the only solution                                                                                  // 479
    try {                                                                                                             // 480
      Tracker.flush();                                                                                                // 481
    } catch(ex) {                                                                                                     // 482
      // only handling "while flushing" errors                                                                        // 483
      if(!/Tracker\.flush while flushing/.test(ex.message)) {                                                         // 484
        return;                                                                                                       // 485
      }                                                                                                               // 486
                                                                                                                      // 487
      // XXX: fix this with a proper solution by removing subscription mgt.                                           // 488
      // from the router. Then we don't need to run invalidate using a tracker                                        // 489
                                                                                                                      // 490
      // this happens when we are trying to invoke a route change                                                     // 491
      // with inside a route chnage. (eg:- Template.onCreated)                                                        // 492
      // Since we use page.js and tracker, we don't have much control                                                 // 493
      // over this process.                                                                                           // 494
      // only solution is to defer route execution.                                                                   // 495
                                                                                                                      // 496
      // It's possible to have more than one path want to defer                                                       // 497
      // But, we only need to pick the last one.                                                                      // 498
      self._nextPath = self._current.path;                                                                            // 499
      Meteor.defer(function() {                                                                                       // 500
        var path = self._nextPath;                                                                                    // 501
        if(!path) {                                                                                                   // 502
          return;                                                                                                     // 503
        }                                                                                                             // 504
                                                                                                                      // 505
        delete self._nextPath;                                                                                        // 506
        self.env.reload.withValue(true, function() {                                                                  // 507
          self.go(path);                                                                                              // 508
        });                                                                                                           // 509
      });                                                                                                             // 510
    }                                                                                                                 // 511
  }                                                                                                                   // 512
};                                                                                                                    // 513
                                                                                                                      // 514
Router.prototype._updateCallbacks = function () {                                                                     // 515
  var self = this;                                                                                                    // 516
                                                                                                                      // 517
  self._page.callbacks = [];                                                                                          // 518
  self._page.exits = [];                                                                                              // 519
                                                                                                                      // 520
  // add global middleware                                                                                            // 521
  _.each(self._middleware, function(fn) {                                                                             // 522
    self._page("*", fn);                                                                                              // 523
  });                                                                                                                 // 524
                                                                                                                      // 525
  _.each(self._routes, function(route) {                                                                              // 526
    self._page(route.path, route._actionHandle);                                                                      // 527
    self._page.exit(route.path, route._exitHandle);                                                                   // 528
  });                                                                                                                 // 529
                                                                                                                      // 530
  self._page("*", function(context) {                                                                                 // 531
    self._notfoundRoute(context);                                                                                     // 532
  });                                                                                                                 // 533
};                                                                                                                    // 534
                                                                                                                      // 535
Router.prototype._initTriggersAPI = function() {                                                                      // 536
  var self = this;                                                                                                    // 537
  this.triggers = {                                                                                                   // 538
    enter: function(triggers, filter) {                                                                               // 539
      triggers = Triggers.applyFilters(triggers, filter);                                                             // 540
      if(triggers.length) {                                                                                           // 541
        self._triggersEnter = self._triggersEnter.concat(triggers);                                                   // 542
      }                                                                                                               // 543
    },                                                                                                                // 544
                                                                                                                      // 545
    exit: function(triggers, filter) {                                                                                // 546
      triggers = Triggers.applyFilters(triggers, filter);                                                             // 547
      if(triggers.length) {                                                                                           // 548
        self._triggersExit = self._triggersExit.concat(triggers);                                                     // 549
      }                                                                                                               // 550
    }                                                                                                                 // 551
  };                                                                                                                  // 552
};                                                                                                                    // 553
                                                                                                                      // 554
Router.prototype.wait = function() {                                                                                  // 555
  if(this._initialized) {                                                                                             // 556
    throw new Error("can't wait after FlowRouter has been initialized");                                              // 557
  }                                                                                                                   // 558
                                                                                                                      // 559
  this._askedToWait = true;                                                                                           // 560
};                                                                                                                    // 561
                                                                                                                      // 562
Router.prototype._page = page;                                                                                        // 563
Router.prototype._qs = qs;                                                                                            // 564
                                                                                                                      // 565
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:flow-router/client/group.js                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Group = function(router, options, parent) {                                                                           // 1
  options = options || {};                                                                                            // 2
                                                                                                                      // 3
  if (options.prefix && !/^\/.*/.test(options.prefix)) {                                                              // 4
    var message = "group's prefix must start with '/'";                                                               // 5
    throw new Error(message);                                                                                         // 6
  }                                                                                                                   // 7
                                                                                                                      // 8
  this._router = router;                                                                                              // 9
  this.prefix = options.prefix || '';                                                                                 // 10
                                                                                                                      // 11
  this._middlewares = options.middlewares || [];                                                                      // 12
  this._triggersEnter = options.triggersEnter || [];                                                                  // 13
  this._triggersExit = options.triggersExit || [];                                                                    // 14
  this._subscriptions = options.subscriptions || Function.prototype;                                                  // 15
                                                                                                                      // 16
  this.parent = parent;                                                                                               // 17
  if (this.parent) {                                                                                                  // 18
    this.prefix = parent.prefix + this.prefix;                                                                        // 19
    this._middlewares = parent._middlewares.concat(this._middlewares);                                                // 20
                                                                                                                      // 21
    this._triggersEnter = parent._triggersEnter.concat(this._triggersEnter);                                          // 22
    this._triggersExit = this._triggersExit.concat(parent._triggersExit);                                             // 23
  }                                                                                                                   // 24
};                                                                                                                    // 25
                                                                                                                      // 26
Group.prototype.route = function(path, options, group) {                                                              // 27
  options = options || {};                                                                                            // 28
                                                                                                                      // 29
  if (!/^\/.*/.test(path)) {                                                                                          // 30
    var message = "route's path must start with '/'";                                                                 // 31
    throw new Error(message);                                                                                         // 32
  }                                                                                                                   // 33
                                                                                                                      // 34
  group = group || this;                                                                                              // 35
  path = this.prefix + path;                                                                                          // 36
                                                                                                                      // 37
  var middlewares = options.middlewares || [];                                                                        // 38
  options.middlewares = this._middlewares.concat(middlewares);                                                        // 39
                                                                                                                      // 40
  var triggersEnter = options.triggersEnter || [];                                                                    // 41
  options.triggersEnter = this._triggersEnter.concat(triggersEnter);                                                  // 42
                                                                                                                      // 43
  var triggersExit = options.triggersExit || [];                                                                      // 44
  options.triggersExit = triggersExit.concat(this._triggersExit);                                                     // 45
                                                                                                                      // 46
  return this._router.route(path, options, group);                                                                    // 47
};                                                                                                                    // 48
                                                                                                                      // 49
Group.prototype.group = function(options) {                                                                           // 50
  return new Group(this._router, options, this);                                                                      // 51
};                                                                                                                    // 52
                                                                                                                      // 53
Group.prototype.callSubscriptions = function(current) {                                                               // 54
  if (this.parent) {                                                                                                  // 55
    this.parent.callSubscriptions(current);                                                                           // 56
  }                                                                                                                   // 57
                                                                                                                      // 58
  this._subscriptions.call(current.route, current.params, current.queryParams);                                       // 59
};                                                                                                                    // 60
                                                                                                                      // 61
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:flow-router/client/route.js                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Route = function(router, path, options, group) {                                                                      // 1
  options = options || {};                                                                                            // 2
                                                                                                                      // 3
  this.path = path;                                                                                                   // 4
  if (options.name) {                                                                                                 // 5
    this.name = options.name;                                                                                         // 6
  }                                                                                                                   // 7
                                                                                                                      // 8
  this._action = options.action || Function.prototype;                                                                // 9
  this._subscriptions = options.subscriptions || Function.prototype;                                                  // 10
  this._triggersEnter = options.triggersEnter || [];                                                                  // 11
  this._triggersExit = options.triggersExit || [];                                                                    // 12
  this._middlewares = options.middlewares || [];                                                                      // 13
  this._subsMap = {};                                                                                                 // 14
  this._router = router;                                                                                              // 15
                                                                                                                      // 16
  this._params = new ReactiveDict();                                                                                  // 17
  this._queryParams = new ReactiveDict();                                                                             // 18
  this._routeCloseDep = new Tracker.Dependency();                                                                     // 19
                                                                                                                      // 20
  // tracks the changes in the URL                                                                                    // 21
  this._pathChangeDep = new Tracker.Dependency();                                                                     // 22
                                                                                                                      // 23
  this.group = group;                                                                                                 // 24
};                                                                                                                    // 25
                                                                                                                      // 26
Route.prototype.clearSubscriptions = function() {                                                                     // 27
  this._subsMap = {};                                                                                                 // 28
};                                                                                                                    // 29
                                                                                                                      // 30
Route.prototype.register = function(name, sub, options) {                                                             // 31
  this._subsMap[name] = sub;                                                                                          // 32
};                                                                                                                    // 33
                                                                                                                      // 34
                                                                                                                      // 35
Route.prototype.getSubscription = function(name) {                                                                    // 36
  return this._subsMap[name];                                                                                         // 37
};                                                                                                                    // 38
                                                                                                                      // 39
                                                                                                                      // 40
Route.prototype.getAllSubscriptions = function() {                                                                    // 41
  return this._subsMap;                                                                                               // 42
};                                                                                                                    // 43
                                                                                                                      // 44
Route.prototype._processMiddlewares = function(context, after) {                                                      // 45
  var currentIndex = 0;                                                                                               // 46
  var self = this;                                                                                                    // 47
                                                                                                                      // 48
  runMiddleware();                                                                                                    // 49
  function runMiddleware() {                                                                                          // 50
    var fn = self._middlewares[currentIndex++];                                                                       // 51
    if(fn) {                                                                                                          // 52
      console.warn("'middleware' is deprecated. Use 'triggers' instead");                                             // 53
      fn(context.path, function(redirectPath) {                                                                       // 54
        if(redirectPath) {                                                                                            // 55
          return self._router.redirect(redirectPath);                                                                 // 56
        } else {                                                                                                      // 57
          runMiddleware();                                                                                            // 58
        }                                                                                                             // 59
      });                                                                                                             // 60
    } else {                                                                                                          // 61
      after();                                                                                                        // 62
    }                                                                                                                 // 63
  }                                                                                                                   // 64
};                                                                                                                    // 65
                                                                                                                      // 66
Route.prototype.callAction = function(current) {                                                                      // 67
  var self = this;                                                                                                    // 68
                                                                                                                      // 69
  self._processMiddlewares(current.context, function() {                                                              // 70
    self._action(current.params, current.queryParams);                                                                // 71
  });                                                                                                                 // 72
};                                                                                                                    // 73
                                                                                                                      // 74
Route.prototype.callSubscriptions = function(current) {                                                               // 75
  this.clearSubscriptions();                                                                                          // 76
  if (this.group) {                                                                                                   // 77
    this.group.callSubscriptions(current);                                                                            // 78
  }                                                                                                                   // 79
                                                                                                                      // 80
  this._subscriptions(current.params, current.queryParams);                                                           // 81
};                                                                                                                    // 82
                                                                                                                      // 83
Route.prototype.getRouteName = function() {                                                                           // 84
  this._routeCloseDep.depend();                                                                                       // 85
  return this.name;                                                                                                   // 86
};                                                                                                                    // 87
                                                                                                                      // 88
Route.prototype.getParam = function(key) {                                                                            // 89
  this._routeCloseDep.depend();                                                                                       // 90
  return this._params.get(key);                                                                                       // 91
};                                                                                                                    // 92
                                                                                                                      // 93
Route.prototype.getQueryParam = function(key) {                                                                       // 94
  this._routeCloseDep.depend();                                                                                       // 95
  return this._queryParams.get(key);                                                                                  // 96
};                                                                                                                    // 97
                                                                                                                      // 98
Route.prototype.watchPathChange = function() {                                                                        // 99
  this._pathChangeDep.depend();                                                                                       // 100
};                                                                                                                    // 101
                                                                                                                      // 102
Route.prototype.registerRouteClose = function() {                                                                     // 103
  this._params = new ReactiveDict();                                                                                  // 104
  this._queryParams = new ReactiveDict();                                                                             // 105
  this._routeCloseDep.changed();                                                                                      // 106
  this._pathChangeDep.changed();                                                                                      // 107
};                                                                                                                    // 108
                                                                                                                      // 109
Route.prototype.registerRouteChange = function(currentContext, routeChanging) {                                       // 110
  // register params                                                                                                  // 111
  var params = currentContext.params;                                                                                 // 112
  this._updateReactiveDict(this._params, params);                                                                     // 113
                                                                                                                      // 114
  // register query params                                                                                            // 115
  var queryParams = currentContext.queryParams;                                                                       // 116
  this._updateReactiveDict(this._queryParams, queryParams);                                                           // 117
                                                                                                                      // 118
  // if the route is changing, we need to defer triggering path changing                                              // 119
  // if we did this, old route's path watchers will detect this                                                       // 120
  // Real issue is, above watcher will get removed with the new route                                                 // 121
  // So, we don't need to trigger it now                                                                              // 122
  // We are doing it on the route close event. So, if they exists they'll                                             // 123
  // get notify that                                                                                                  // 124
  if(!routeChanging) {                                                                                                // 125
    this._pathChangeDep.changed();                                                                                    // 126
  }                                                                                                                   // 127
};                                                                                                                    // 128
                                                                                                                      // 129
Route.prototype._updateReactiveDict = function(dict, newValues) {                                                     // 130
  var currentKeys = _.keys(newValues);                                                                                // 131
  var oldKeys = _.keys(dict.keyDeps);                                                                                 // 132
                                                                                                                      // 133
  // set new values                                                                                                   // 134
  //  params is an array. So, _.each(params) does not works                                                           // 135
  //  to iterate params                                                                                               // 136
  _.each(currentKeys, function(key) {                                                                                 // 137
    dict.set(key, newValues[key]);                                                                                    // 138
  });                                                                                                                 // 139
                                                                                                                      // 140
  // remove keys which does not exisits here                                                                          // 141
  var removedKeys = _.difference(oldKeys, currentKeys);                                                               // 142
  _.each(removedKeys, function(key) {                                                                                 // 143
    dict.set(key, undefined);                                                                                         // 144
  });                                                                                                                 // 145
};                                                                                                                    // 146
                                                                                                                      // 147
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:flow-router/client/_init.js                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// Export Router Instance                                                                                             // 1
FlowRouter = new Router();                                                                                            // 2
FlowRouter.Router = Router;                                                                                           // 3
FlowRouter.Route = Route;                                                                                             // 4
                                                                                                                      // 5
// Initialize FlowRouter                                                                                              // 6
Meteor.startup(function () {                                                                                          // 7
  if(!FlowRouter._askedToWait) {                                                                                      // 8
    FlowRouter.initialize();                                                                                          // 9
  }                                                                                                                   // 10
});                                                                                                                   // 11
                                                                                                                      // 12
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['meteorhacks:flow-router'] = {
  FlowRouter: FlowRouter
};

})();
