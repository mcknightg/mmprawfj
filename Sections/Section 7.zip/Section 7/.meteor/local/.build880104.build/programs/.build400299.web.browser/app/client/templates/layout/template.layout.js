(function(){
Template.__checkName("layout");
Template["layout"] = new Template("Template.layout", (function() {
  var view = this;
  return [ Spacebars.include(view.lookupTemplate("header")), "\n    ", HTML.DIV({
    "class": "container-fluid "
  }, "\n        ", HTML.DIV({
    "class": "row "
  }, "\n            ", HTML.DIV({
    "class": "col-md-2"
  }, "\n                ", Blaze._TemplateWith(function() {
    return {
      template: Spacebars.call(view.lookup("sidebar"))
    };
  }, function() {
    return Spacebars.include(function() {
      return Spacebars.call(Template.__dynamic);
    });
  }), "\n            "), "\n            ", HTML.DIV({
    "class": "col-md-8"
  }, "\n                ", Blaze._TemplateWith(function() {
    return {
      template: Spacebars.call(view.lookup("main"))
    };
  }, function() {
    return Spacebars.include(function() {
      return Spacebars.call(Template.__dynamic);
    });
  }), "\n            "), "\n            ", HTML.DIV({
    "class": "col-md-2"
  }, "\n                ", Blaze.If(function() {
    return Spacebars.call(view.lookup("currentUser"));
  }, function() {
    return [ "\n                ", Blaze._TemplateWith(function() {
      return {
        template: Spacebars.call(view.lookup("cart"))
      };
    }, function() {
      return Spacebars.include(function() {
        return Spacebars.call(Template.__dynamic);
      });
    }), "\n                " ];
  }), "\n            "), "\n        "), "\n    ") ];
}));

})();
